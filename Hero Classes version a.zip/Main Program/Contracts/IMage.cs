﻿namespace Main_Program
{
    public interface IMage
    {
        string GetFields();
    }
}