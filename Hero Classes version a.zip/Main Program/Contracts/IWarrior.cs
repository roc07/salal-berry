﻿namespace Main_Program
{
    public interface IWarrior
    {
        string GetFields();
    }
}