﻿namespace Main_Program
{
    public enum Quality
    {
        Broken, Damaged, Average, Crafted, Artifact
    }
}
