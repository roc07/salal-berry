﻿
namespace Main_Program
{
    public enum Potentialities
    {
        Barracks = 1, MagicTower = 8, Forrest = 2, YogaТeacher = 2, InvisibleTrap = 1, RiverOfLife = 10
    }
}
