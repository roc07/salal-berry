﻿using System;

namespace Main_Program
{
    public enum ArmorType
    {
        leather, mail, plate
    }
}
