﻿namespace Main_Program
{
	public enum DifficultyLevel
	{
		Easy, Medium, Hard
	}
}
