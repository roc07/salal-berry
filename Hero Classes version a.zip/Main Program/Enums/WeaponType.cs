﻿namespace Main_Program
{
    public enum WeaponType
    {
        Spear, Sword, Knife, Hammer, Axe
    }
}
