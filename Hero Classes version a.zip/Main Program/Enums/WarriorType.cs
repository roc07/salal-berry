﻿namespace Main_Program
{
    //delete
	public enum WarriorType
	{
	}
}
