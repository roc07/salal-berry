﻿namespace Main_Program
{
	public enum MonsterType
	{
		orc, ogre, snake
	}
}
