﻿namespace Main_Program
{
	public enum BanditType
	{
		hunter, thief
	}
}
