﻿using System;
using System.Threading;

namespace Main_Program
{
    class StartClass
    {
        static void Main()
        {
            Actions programStart = new Actions();
            programStart.Battle();
        }
    }
}