﻿using System;

namespace Main_Program
{
    public enum Size
    {
        Large, Average, Small
    }
}
