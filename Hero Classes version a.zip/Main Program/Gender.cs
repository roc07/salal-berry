﻿namespace Main_Program
{
    public enum Gender
    {
        Male, Female
    }
}
