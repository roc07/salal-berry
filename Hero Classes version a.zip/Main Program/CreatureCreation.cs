﻿using System;
namespace Main_Program
{
	public class CreatureCreation
	{
		public CreatureCreation()
		{
		}
	}
}
