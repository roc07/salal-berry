﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main_Program
{
    enum Difficulty
    {
        VeryEasy, Easy, Medium, Hard, VeryHard
    }
}
